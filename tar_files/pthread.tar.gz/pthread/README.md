#Instructions to run

* gcc filename.c -o a -lpthread -lm
* For prio.c, you may have to run it with sudo.
