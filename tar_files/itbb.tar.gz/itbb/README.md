# Insturtions to Run

* Install ICC from: https://software.intel.com/content/www/us/en/develop/tools/system-studio/choose-download.html.
* To create execuatble: icc filename.cpp -tbb
