# Instructions to run

* Setup OpenCL according to your system specs.
* To create executable: gcc filename.c -o a -lOpenCL -lm
